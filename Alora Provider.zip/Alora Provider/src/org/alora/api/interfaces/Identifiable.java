package org.alora.api.interfaces;

/**
 * Created by Ethan on 2/27/2018.
 */
public interface Identifiable {
    int getId();
    long getHash();
}